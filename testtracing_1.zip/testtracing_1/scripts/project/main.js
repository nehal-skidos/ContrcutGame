// References to loaded audio files as global variables
// let audios = []

//creator's Name: SKIDOS 
// Developer's Name: Kartik Singh
// import * as lzs from "https://cdnjs.cloudflare.com/ajax/libs/lz-string/1.4.4/lz-string.min.js";

let loadLocal = false;
let json_data;
let IS_RELOADING = false;
let mainData = {};
let Muted = false;
runOnStartup(async runtime =>
{
	runtime.globalVars.UNIWEBVIEW_SCHEMA = "skidoswebview";
	if(window.data){
		
		mainData = window.data;
		window.data = undefined;
		
		runtime.globalVars.AuthJsonStr = JSON.stringify(mainData);
		runtime.globalVars.IS_ANALYTICS = true;
		runtime.globalVars.IS_TESTING = false;	
		
		
	}
	else
	{
	console.log("window.data is null");
		runtime.globalVars.IS_ANALYTICS = false;
		runtime.globalVars.IS_TESTING = false;	
	
	}

	runtime.addEventListener("beforeprojectstart", () => OnBeforeProjectStart(runtime));
});

async function OnBeforeProjectStart(runtime)
{

	/* Code to run just before 'On start of layout' on
	the first layout. Loading has finished and initial
	instances are created and available to use here. */
	
	runtime.addEventListener("tick", () => Tick(runtime));
}


//
function Tick(runtime)
{
	// Code to run every tick
}

async function getLangCode(){
	let langCode = prompt("Please enter your language code:", "en_gb");
		  if (langCode == null || langCode == "") {
			langCode = "en_gb"
			
		  }
	return langCode
}

async function fetchJsonData(runtime, name ){
	let jsonData;
	jsonData =  await runtime.assets.fetchJson(name)
	return jsonData;
	}
	
  


   
        
        
