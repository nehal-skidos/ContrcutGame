


const scriptsInEvents = {

	async Es_loader_Event6_Act3(runtime, localVars)
	{
		let jsonData = runtime.objects.JsonEntryData.getFirstInstance().getJsonDataCopy();
		
		runtime.globalVars.SubjectsCount= Object.keys(jsonData.Subjects).length
	},

	async Es_loader_Event8_Act2(runtime, localVars)
	{
			
			let authJSON = {};
		authJSON = JSON.parse(runtime.globalVars.AuthJsonStr);
			let jsonData =  await runtime.assets.fetchJson("en_us.json");
				
					runtime.globalVars.IS_BALLOON_CLICKED = jsonData.balloonClicked;
		            runtime.globalVars.JsonDataStr = JSON.stringify(jsonData);
					runtime.globalVars.IS_TEST_BUILD = authJSON.testServer;
		// 			runtime.objects.JsonEntryData.getFirstInstance().setJsonDataCopy(jsonData);
		            runtime.callFunction("LoadSounds");     
	},

	async Es_loader_Event10_Act1(runtime, localVars)
	{
		  
		  if(runtime.globalVars.AuthJsonStr==""){
		  	login();
		  }
		  else{
		  runtime.callFunction("StartLoading");
		  }
		  
		   function login() 
		   {
		      let authJSON={};
		      let loginJson ={"email":"test.landing@yopmail.com","password":"thincall28"};
		//  let loginJson = {"email": "newemai11lmy@test.com", "password": "flakycomic96"};
		      const xhttp = new XMLHttpRequest();
		      xhttp.open("POST", "https://apitest.skidos.com/apis/userservice/v1/login");
		      xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
		      xhttp.send(JSON.stringify(loginJson));
		      xhttp.onreadystatechange = function () 
		      {
		         if (this.readyState == 4) 
		         {
		            let respJson =JSON.parse(this.responseText);
		            if (this["status"] == 200) 
		            {
		               
		               
		               authJSON.authToken =  this.getResponseHeader("auth_token")
		               authJSON.refToken =  this.getResponseHeader("refresh_token");                                    console.log("logged in", respJson);             
		               authJSON.lang = respJson.Language;
		               authJSON.version = respJson.SDKVersion;
		               authJSON.platform="iOS";
		               authJSON.sessionId="a3a46bf2-01ba-45f4-9bf1-982efade2db8";
		               authJSON.testServer = 1;
		               authJSON.gameId = "sdk";
		               authJSON.progressAPIBody = {};
		               authJSON.playerId = "86014";
					   authJSON.userId = "114971"
		               authJSON.subject = "preschool"
		               authJSON.subscribed = false;
		            authJSON.lockedData = {};
		            authJSON.lockedData = { "header": "Hello!","body": "Subscribe to unlock all the letter and numbers", "footer": "Ok"};
					  authJSON.did = "";
					  authJSON.orientation = "port";            
					  authJSON.balloonClicked = true;			
		           	  authJSON.subSubject = "ABC";					 
		              console.log(this.getAllResponseHeaders());
		              runtime.globalVars.AuthJsonStr = JSON.stringify(authJSON);
		
		               runtime.callFunction("StartLoading");
		            }
		         };
		         return false;
		         }
		   }
		
		  
	},

	async Es_loader_Event11_Act1(runtime, localVars)
	{
		
		  var x = document.getElementById("snackbar");
		  x.className = "show";
		  let text = document.getElementById("snackbar").innerText = localVars.messege;
		  setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
		
	},

	async Es_common_Event15_Act1(runtime, localVars)
	{
		
		let returnValue = 0 ;
		
		if(localVars.letter.length == 2 && localVars.current_frame == 1){
			localVars.letter = localVars.letter.charAt(localVars.letter.length - 1);
		}
		// console.log("LETTER ::::"+localVars.letter)
		switch(localVars.letter)
		{
			case "3":
			returnValue = -25;
			break
		
			case "5":
			returnValue = 32;
			break	
			
		
			case "6":
			returnValue = 30;
			break
		
		
			case "9":
			returnValue = -25;
			break
			
			
			
			default:
			returnValue = 0;
		}
		console.log("LETTER ::::"+localVars.letter+", Angle:"+returnValue)
		runtime.setReturnValue(returnValue);
	},

	async Es_common_Event27_Act1(runtime, localVars)
	{
		
		
		let colorRGB = new Map();
		colorRGB.set("Loader", "rgb(133, 233, 216)");
		colorRGB.set("Home", "rgb(133, 233, 216)");
		
		colorRGB.set("Tracing", "rgb(0, 198, 163)");
		colorRGB.set("Alphabet Selection Capital", "rgb(0, 198, 163)");
		colorRGB.set("Alphabet Selection Small", "rgb(0, 198, 163)");
		colorRGB.set("Number Selection", "rgb(0, 198, 163)");
		
		
		let color = colorRGB.get(localVars.name);
		console.log("SET COLOR:====> ", color)
		document.body.style.backgroundColor = color;
		document.getElementsByTagName("html")[0].style.background =  color;
	},

	async Es_alphabetselectioncapital_Event2_Act4(runtime, localVars)
	{
		
		const data =runtime.objects.EventNames.getFirstInstance().getDataMap();
		let href= "skidoswebview://SkidosTracingPageLanded?is_reached=1&EventName="+data.get("278")+"&webmodule="+runtime.globalVars.WebModule;
		console.log("href = "+href);
		if(runtime.globalVars.IS_ANALYTICS)
		window.location.href  = href;
		
	},

	async Es_alphabetselectioncapital_Event4_Act1(runtime, localVars)
	{
		let jsonData = runtime.objects.JsonEntryData.getFirstInstance().getJsonDataCopy();
		
		runtime.globalVars.LettersCount= Object.keys(jsonData.GameData[runtime.globalVars.SubjectTypeIndex].Played).length;
	},

	async Es_tracing_capital_Event81_Act2(runtime, localVars)
	{
		//Neucha-Regular font
					console.log(runtime.objects.ObjectNameText.getFirstInstance().fontFace);
					let letter = localVars.first_letter;
					// alert("value - "+letter);
					
					if(letter =="j" || letter =="p" || letter =="q" || letter =="g" || letter =="y"){
					localVars.padding_value = 170;
					}
					 else if(letter =="b" || letter == "d" || letter =="f" || letter =="h" || letter =="k" || letter =="l" || letter =="t" || letter =="i" ){
					// alert("value - "+letter)
					localVars.padding_value = 154;
					
					}
					else if(letter =="å" || letter =="ä"){
					localVars.padding_value = 150
					}
					else if(letter == "ö" || letter=="ñ"){
					localVars.padding_value = 150
					}
					else{
					localVars.padding_value = 162;
					}
					
	},

	async Es_analytics_Event3_Act1(runtime, localVars)
	{
		let href = runtime.globalVars.UNIWEBVIEW_SCHEMA +"://SendAnalytics?"+localVars["data"]+"&webmodule="+runtime.globalVars.WebModule;
		console.log("href = "+href);
		if(runtime.globalVars.IS_ANALYTICS)
		window.location.href = href;
		
	},

	async Es_analytics_Event4_Act1(runtime, localVars)
	{
		
		let authJSON = JSON.parse(runtime.globalVars.AuthJsonStr);
		let apiURL =  "https://"+(authJSON.testServer == 1?"apitest":"api")+".skidos.com/apis/productservice/v1/toddler/solution/?l="+authJSON.lang+"&gameid="+authJSON.gameId+"&version="+authJSON.version+"&platform="+authJSON.platform+"&sessionID="+authJSON.sessionId+"&did="+authJSON.did+"&ornt="+authJSON.orientation;
		
		let submitAPIBody = {"subject":localVars.subject,"sub_subject":localVars.sub_subject ,"character":localVars.character, "player_id": authJSON.playerId,"user_id":authJSON.userId, "game_id":authJSON.gameId, "language":authJSON.lang };
		
		
		 console.log("apiURL: ",apiURL)
		
		 	console.log("authToken", authJSON.authToken)
		   const xhttp = new XMLHttpRequest();           
		   xhttp.open("POST", apiURL);
		   xhttp.setRequestHeader("Content-Type", "application/json; charset=UTF-8");
		   xhttp.setRequestHeader("Authorization", authJSON.authToken); 
		     console.log("submitAPIBody::",JSON.stringify(submitAPIBody))
		   xhttp.send(JSON.stringify(submitAPIBody));
		  
		   xhttp.onreadystatechange = function () 
		   {
		    console.log(">>>> Status:",this["status"], "State: ",this.readyState);
		      if (this.readyState == 4) 
		      {                     
		
		         if (this["status"] == 200) 
		         {                                
		            console.log("submitted succesfully", this.responseText);
		            
		         }
				 else{
				 	console.log("Error: ", this.status)
				 }
		      };
		//    return false;
		   }
		
		   
	},

	async Es_analytics_Event5_Act2(runtime, localVars)
	{
		
		let href = runtime.globalVars.UNIWEBVIEW_SCHEMA +"://ExitFromWebView?exit=1";
		
		if(localVars.data!=undefined ){
			if(runtime.globalVars.IS_BALLOON_CLICKED == 0){
				href += (localVars.data!=""?"&":"")+localVars.data+ "&question_attempted="+(runtime.globalVars.Question_Attempted==1?"true":"false");
				runtime.globalVars.Question_Attempted = 0;
			}
			else 
				href += (localVars.data!=""?"&":"")+localVars.data+ "&question_attempted=false";
		}
		href+="&webmodule="+runtime.globalVars.WebModule;
		console.log("href = "+href);
		
		if(runtime.globalVars.IS_ANALYTICS)
		window.location.href = href;
	},

	async Es_analytics_Event6_Act1(runtime, localVars)
	{
		let href = runtime.globalVars.UNIWEBVIEW_SCHEMA +"://ShowSubscription?opensubscription=1";
		if(localVars.data!=undefined && localVars.data!=""){
		
		href += "&"+localVars.data;
		}
		
		href+="&webmodule="+runtime.globalVars.WebModule;
		
		console.log("href = "+href);
		if(runtime.globalVars.IS_ANALYTICS)
		window.location.href = href;
		
		
		
		
	},

	async Es_analytics_Event7_Act1(runtime, localVars)
	{
		let href = runtime.globalVars.UNIWEBVIEW_SCHEMA+"://PlayUnitySound?play=1";
		
		if(localVars.data!=undefined && localVars.data!=""){
		
		href += "&"+localVars.data;
		}
		console.log("href = "+href);
		if(runtime.globalVars.IS_ANALYTICS)
		window.location.href = href;
		
	},

	async Es_analytics_Event11_Act1(runtime, localVars)
	{
		
		let href = runtime.globalVars.UNIWEBVIEW_SCHEMA +"skidoswebview://pagevisibility?isvisible="+localVars.is_page_suspended;
		console.log("href = "+href);
		if(runtime.globalVars.IS_ANALYTICS)
		window.location.href = href;
		
		
	},

	async Es_analytics_Event12_Act1(runtime, localVars)
	{
		let href = runtime.globalVars.UNIWEBVIEW_SCHEMA +"://SaveAuthData?"+localVars["data"]+"&webmodule="+runtime.globalVars.WebModule;
		href = href.replaceAll(" ", "");
		console.log("href = "+href);
		if(runtime.globalVars.IS_ANALYTICS){
		
			window.location.href = href;
			
		}
		
	},

	async Es_analytics_Event14_Act1(runtime, localVars)
	{
		let href = runtime.globalVars.UNIWEBVIEW_SCHEMA +"://LogOutFromWeb?"+localVars["data"]+"&webmodule="+runtime.globalVars.WebModule;
			href = href.replaceAll(" ", "");
		console.log("href = "+href);
		if(runtime.globalVars.IS_ANALYTICS){
		
			window.location.href = href;
			
		}
		
	}

};

self.C3.ScriptsInEvents = scriptsInEvents;

